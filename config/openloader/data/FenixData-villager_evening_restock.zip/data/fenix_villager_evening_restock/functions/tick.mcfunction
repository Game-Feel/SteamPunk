scoreboard players add #timer fver_tick 1
execute if score #timer fver_tick matches 20.. run function fenix_villager_evening_restock:check
