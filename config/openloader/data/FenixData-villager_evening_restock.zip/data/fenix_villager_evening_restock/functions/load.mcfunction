scoreboard objectives add fver_tick dummy
scoreboard objectives add fver_time dummy
scoreboard players set #timer fver_tick 0
scoreboard players set #daytime fver_time 0
tellraw @a {"text":"[Fenix Villager Evening Restock] loaded","color":"green"}
