data modify entity @s Offers.Recipes[].uses set value 0
data modify entity @s RestocksToday set value 0
