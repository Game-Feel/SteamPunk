scoreboard players set #timer fver_tick 0
execute store result score #daytime fver_time run time query daytime
execute if score #daytime fver_time matches 2000..2100 as @e[type=minecraft:villager] run function fenix_villager_evening_restock:restock_self
execute if score #daytime fver_time matches 8000..8100 as @e[type=minecraft:villager] run function fenix_villager_evening_restock:restock_self
execute if score #daytime fver_time matches 12000..12100 as @e[type=minecraft:villager] run function fenix_villager_evening_restock:restock_self
execute if score #daytime fver_time matches 16000..16100 as @e[type=minecraft:villager] run function fenix_villager_evening_restock:restock_self
execute if score #daytime fver_time matches 18000..18100 as @e[type=minecraft:villager] run function fenix_villager_evening_restock:restock_self
