Fenix Villager Evening Restock

Minecraft: Java 1.20.1 datapack, pack_format 15.

What it does:
- Adds extra trade restock windows during the day and evening.
- Resets villager trade uses at roughly daytime 2000, 8000, 12000, 16000, and 18000.
- Also resets RestocksToday to let vanilla restock logic breathe on the next normal work cycle.

What it cannot do:
- It cannot fully change villager AI schedules or force job-site / workstation claiming in the evening.
- For true evening workstation refresh, use a Forge/KubeJS/mixin solution, not a datapack.

Install:
- World only: put this zip into saves/<world>/datapacks/
- All worlds with OpenLoader: put this zip into config/openloader/data/
- Run /reload or restart the world/server.

Test:
- /datapack list
- /function fenix_villager_evening_restock:check
