Что делает:
- Не меняет дроп блоков и не трогает loot tables.
- Чинит x2 от апгрейда Ore Processing в Better Furnaces Reforged для:
  - рудных блоков (ores)
  - сырой руды (raw ores / raw materials)
- Сохраняет твои спец-кейсы (diamond_block, ancient_debri_nugget и т.д.).

Что отключить (чтобы не конфликтовало):
- bfr_ore_processing_extras_datapack.zip
- bfr_ore_processing_extras_outputs_datapack.zip
- bfr_ore_processing_x2_all_smelting_inputs.zip

Установка:
- world/datapacks/ (или saves/<мир>/datapacks/)
- /reload или перезапуск

Если какая-то модовая сырая руда всё ещё даёт x1:
- скорее всего мод не кладёт её в forge/c raw_materials теги.
- тогда нужно добавить конкретный item id в raw_ore.json вручную.


- Raw ores fix: adds Forge/C raw_materials tags and includes them in #forge:ores so the Ore Processing Upgrade doubles raw ores too.
