execute as @e[type=minecraft:villager] run data remove entity @s Gossips
