execute as @e[type=minecraft:villager] run data remove entity @s Gossips
schedule function fenix_gossip_reset:daily 24000t replace
