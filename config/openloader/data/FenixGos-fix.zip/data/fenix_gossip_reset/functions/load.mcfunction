schedule function fenix_gossip_reset:daily 24000t replace
